Diagnosing a stateful service and returning it intact: reproduction

Requirements
Python 3.14 with its standard library and sqlite3 module, on a POSIX system.

Command
python3.14 -B reproduce.py

The script creates runs/<UTC timestamp>/, copies code/ into it and runs compute, verify, native and tables in that order, each as a separate process with a CPU limit of 18 seconds (raise it with --cpu-limit 120 on slow hardware). Process output goes to <stage>.stdout and <stage>.stderr; exit codes and times go to processes.json. A failing stage ends the run.

The summaries named in expected.json are then compared with it, ignoring the Python and SQLite versions, elapsed times and the record count field. A full match prints PASS and writes CHECK.json.

Expected counts
46,912 services in the complete population; 14,706,880 rank entries rechecked by code/verify.py; 174,632 policy replays; 44 native transitions, 34 diagnostic episodes and 13 interrupted cleanup episodes against SQLite.

Inputs
code/compute.py and code/native.py generate every service and native case; no download is needed. code/tables.py writes the LaTeX table rows and number macros of the paper into latex/ inside the run directory.

Files
RESULTS.tsv gives, for each table, the program, the line that writes the output and the output path. ENVIRONMENT.json records the platform of the reference run.
