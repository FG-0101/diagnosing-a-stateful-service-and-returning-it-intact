"""Constructed persistent SQLite services; exact extraction and native policy replay."""
import collections,itertools,json,pathlib,sqlite3,time
ROOT=pathlib.Path(__file__).resolve().parents[1]

class Service:
    def __init__(self,kind,secret):
        self.kind=kind;self.db=sqlite3.connect(':memory:',isolation_level=None)
        self.db.execute('CREATE TABLE cell (v INTEGER NOT NULL CHECK(v IN(0,1)))')
        self.db.execute('INSERT INTO cell VALUES (?)',(secret,))
        self.audit=sqlite3.connect(':memory:',isolation_level=None)
        self.audit.execute('CREATE TABLE event (v INTEGER NOT NULL)')
        self.original=-1
    def state(self):
        return (self.db.execute('SELECT v FROM cell').fetchone()[0],self.original,
                self.audit.execute('SELECT COUNT(*) FROM event').fetchone()[0])
    def call(self,action):
        if action=='noop':return 'ok'
        if action=='peek':return str(self.state()[0])
        if action=='consume':
            value=self.state()[0];self.db.execute('UPDATE cell SET v=0');return str(value)
        if action=='flip':
            value=self.state()[0];self.db.execute('UPDATE cell SET v=1-v');return str(value)
        if action in ('write0','write1'):
            self.db.execute('UPDATE cell SET v=?',(int(action[-1]),));return 'ok'
        if action=='probe':
            if self.original>=0 or (self.kind=='external_audit' and self.state()[2]):return 'blocked'
            value=self.state()[0];self.db.execute('SAVEPOINT diagnostic');self.original=value
            if self.kind=='external_audit':self.audit.execute('INSERT INTO event VALUES (1)')
            self.db.execute('UPDATE cell SET v=0');return str(value)
        if action=='rollback':
            if self.original>=0:
                self.db.execute('ROLLBACK TO diagnostic');self.db.execute('RELEASE diagnostic');self.original=-1
            return 'ok'
        raise ValueError(action)
    def close(self):self.db.close();self.audit.close()

def reference(kind,state,action):
    value,original,audit=state
    if action=='noop':return state,'ok'
    if action=='peek':return state,str(value)
    if action=='consume':return (0,original,audit),str(value)
    if action=='flip':return (1-value,original,audit),str(value)
    if action in ('write0','write1'):return (int(action[-1]),original,audit),'ok'
    if action=='probe':
        if original>=0 or (kind=='external_audit' and audit):return state,'blocked'
        return (0,value,audit+(kind=='external_audit')),str(value)
    if action=='rollback':return ((original,-1,audit) if original>=0 else state),'ok'
    raise ValueError(action)

CASES=[('peek',['peek','noop'],['noop']),('consume',['consume','noop'],['noop']),
       ('write_restore',['consume','write0','write1'],['write0','write1']),
       ('blind_cleanup',['consume','write0','write1'],['write0']),
       ('flip',['flip','noop'],['flip']),('transaction',['probe','rollback'],['rollback']),
       ('external_audit',['probe','rollback'],['rollback'])]

def extract(kind,actions):
    witnesses={};initial=[]
    for secret in (0,1):
        service=Service(kind,secret);state=service.state();service.close()
        witnesses[state]=(secret,[]);initial.append(state)
    queue=list(witnesses);edges={};probes=0
    for state in queue:
        secret,word=witnesses[state]
        for action in actions:
            service=Service(kind,secret)
            for a in word:service.call(a)
            assert service.state()==state
            output=service.call(action);nxt=service.state();service.close();probes+=1
            assert (nxt,output)==reference(kind,state,action),(kind,state,action,nxt,output)
            edges[(state,action)]=(nxt,output)
            if nxt not in witnesses:witnesses[nxt]=(secret,word+[action]);queue.append(nxt)
    return initial,queue,edges,probes

def synthesize(initial,states,edges,actions,cleanup):
    configs=[tuple(x) for x in itertools.product([None]+states,repeat=2) if any(s is not None for s in x)]
    graph={}
    for b in configs:
        graph[b]={}
        for a in actions:
            outputs={edges[(s,a)][1] for s in b if s is not None}
            graph[b][a]={y:tuple(edges[(s,a)][0] if s is not None and edges[(s,a)][1]==y else None for s in b) for y in sorted(outputs)}
    returned=lambda b:all(s is None or s==initial[i] for i,s in enumerate(b))
    pure=lambda b:sum(s is not None for s in b)==1
    def layers(goal,choices,allowed=lambda b:True):
        rank={b:0 for b in configs if allowed(b) and goal(b)};policy={};k=0
        while True:
            additions={}
            for b in configs:
                if b in rank or not allowed(b):continue
                for a in choices(b):
                    if all(c in rank for c in graph[b][a].values()):additions[b]=a;break
            if not additions:return rank,policy
            k+=1
            for b,a in additions.items():rank[b]=k;policy[b]=a
    cr,cp=layers(returned,lambda b:cleanup)
    out={'cleanup':(cr,cp)}
    out['identify']=layers(pure,lambda b:actions)
    out['restore']=layers(lambda b:pure(b) and returned(b),lambda b:actions)
    out['abort']=layers(lambda b:pure(b) and returned(b),lambda b:actions,lambda b:b in cr)
    out['readonly']=layers(pure,lambda b:[a for a in actions if all(s is None or edges[(s,a)][0]==s for s in b)])
    return tuple(initial),graph,out

def main():
    result=[];trace=[];native_probes=0;episodes=0;interruptions=0
    for kind,actions,cleanup in CASES:
        initial,states,edges,probes=extract(kind,actions);native_probes+=probes
        root,graph,solved=synthesize(initial,states,edges,actions,cleanup)
        ranks={m:r.get(root) for m,(r,p) in solved.items()}
        result.append({'case':kind,'actions':actions,'cleanup':cleanup,'states':len(states),'extracted_transitions':probes,'root_ranks':ranks,
                       'initial':initial,'transitions':[{'state':s,'action':a,'next':n,'output':y} for (s,a),(n,y) in edges.items()]})
        for mode in ('identify','restore','abort','readonly'):
            rank,policy=solved[mode]
            if root not in rank:continue
            for secret in (0,1):
                service=Service(kind,secret);b=root;word=[]
                while rank[b]>0:
                    action=policy[b];y=service.call(action);word.append(action);b=graph[b][action][y]
                    assert service.state()==b[secret]
                    trace.append({'case':kind,'mode':mode,'secret':secret,'step':len(word),'action':action,'output':y,'state':service.state()})
                    if mode=='abort':
                        interrupted=Service(kind,secret)
                        for a in word:interrupted.call(a)
                        cb=b;cr,cp=solved['cleanup'];cword=[]
                        while cr[cb]>0:
                            ca=cp[cb];cy=interrupted.call(ca);cword.append(ca);cb=graph[cb][ca][cy]
                        assert interrupted.state()==initial[secret]
                        trace.append({'case':kind,'mode':'interrupt_cleanup','secret':secret,'prefix':word.copy(),'cleanup':cword,'final':interrupted.state()})
                        interruptions+=1;interrupted.close()
                assert sum(s is not None for s in b)==1 and b[secret] is not None
                if mode in ('restore','abort'):assert service.state()==initial[secret]
                episodes+=1;service.close()
    out={'status':'PASS','cases':result,'native_transition_probes':native_probes,'persistent_policy_episodes':episodes,
         'interrupted_prefix_episodes':interruptions,'model_native_discrepancies':0,'sqlite_version':sqlite3.sqlite_version,
         'contract':'completed invocations with delivered observations; local in-memory database, no concurrent writers, fresh instance only between episodes',
         'offline_extraction':'fresh reconstruction from witnesses is used to inspect the finite transition table; persistent policy episodes never reset'}
    (ROOT/'results'/'native_summary.json').write_text(json.dumps(out,indent=2)+'\n')
    (ROOT/'data'/'native_trace.jsonl').write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in trace))
    print(json.dumps({k:v for k,v in out.items() if k!='cases'},indent=2))
    for x in result:print(x['case'],x['states'],x['root_ranks'])
if __name__=='__main__':main()
