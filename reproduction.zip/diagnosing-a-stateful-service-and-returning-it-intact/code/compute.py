"""Enumerate every labelled two-action binary-output machine with two or three states."""
import collections, gzip, io, itertools, json, pathlib, sys, time
from model import MODES, solve

ROOT = pathlib.Path(__file__).resolve().parents[1]

def main():
    start = time.monotonic()
    summaries, examples = {}, {}
    path = ROOT/'data'/'exhaustive.jsonl.gz'
    path.parent.mkdir(exist_ok=True)
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as stream:
        for n in (2,3):
            counts = collections.Counter()
            depth = {m: collections.Counter() for m in MODES}
            for mid, code in enumerate(itertools.product(range(2*n), repeat=2*n)):
                states, edges, ranks, root, reset, pairwise = solve(n, code)
                win = {m: ranks[m][root] is not None for m in MODES}
                counts['machines'] += 1
                for m in MODES:
                    counts[m] += win[m]
                    if win[m]: depth[m][ranks[m][root]] += 1
                counts['reset'] += reset
                counts['pairwise'] += pairwise
                tests = {'reset_false_admission': reset and not win['restore'],
                         'identity_without_return': win['identify'] and not win['restore'],
                         'normal_without_abort': win['restore'] and not win['abort'],
                         'pairwise_without_global': pairwise and not win['identify'],
                         'restore_requires_mutation': win['restore'] and not win['readonly']}
                for name, yes in tests.items():
                    counts[name] += yes
                    if yes and name not in examples:
                        examples[name] = {'n': n, 'id': mid, 'code': code, 'root_ranks': {m:ranks[m][root] for m in MODES}}
                row = {'n':n,'id':mid,'code':code,'root':root,'ranks':ranks,'reset':reset,'pairwise':pairwise}
                data = (json.dumps(row,separators=(',',':'))+'\n').encode()
                stream.write(data)
                if mid and mid%5000 == 0: print(json.dumps({'n':n,'completed':mid,'elapsed_seconds':round(time.monotonic()-start,2)}),flush=True)
            summaries[str(n)] = {'counts':dict(counts),'depth':{m:dict(d) for m,d in depth.items()},'configuration_count':len(states)}
    result = {'population':summaries,'examples':examples,'rows':sum(x['counts']['machines'] for x in summaries.values()),
              'record_count':sum(x['counts']['machines'] for x in summaries.values())}
    (ROOT/'results'/'exhaustive_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)
    print(json.dumps({'elapsed_seconds':time.monotonic()-start,'python':sys.version}),flush=True)

if __name__=='__main__':main()
