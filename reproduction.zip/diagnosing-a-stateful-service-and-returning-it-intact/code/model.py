"""Finite labelled service semantics and unit-cost attractor construction."""
from itertools import product

MODES = ('identify', 'restore', 'cleanup', 'abort', 'readonly')

def vectors(n):
    return [x for x in product(range(-1, n), repeat=n) if any(s >= 0 for s in x)]

def graph(n, code):
    states = vectors(n)
    index = {b: i for i, b in enumerate(states)}
    edges = []
    stable = []
    for b in states:
        row, ro = [], []
        for a in range(2):
            children = []
            for y in range(2):
                c = tuple(code[2*s+a]//2 if s >= 0 and code[2*s+a]%2 == y else -1 for s in b)
                if any(s >= 0 for s in c):
                    children.append(index[c])
            row.append(tuple(children))
            ro.append(all(s < 0 or code[2*s+a]//2 == s for s in b))
        edges.append(row)
        stable.append(ro)
    return states, index, edges, stable

def attractor(edges, goals, actions, allowed=None):
    """Synchronous layers give the exact minimum worst-case number of calls."""
    allowed = [True]*len(edges) if allowed is None else allowed
    ranks = [0 if goals[i] and allowed[i] else None for i in range(len(edges))]
    depth = 0
    while True:
        new = []
        for i, row in enumerate(edges):
            if ranks[i] is not None or not allowed[i]:
                continue
            for a in actions[i]:
                if all(ranks[j] is not None for j in row[a]):
                    new.append(i)
                    break
        if not new:
            return ranks
        depth += 1
        for i in new:
            ranks[i] = depth

def solve(n, code):
    states, index, edges, stable = graph(n, code)
    pure = [sum(s >= 0 for s in b) == 1 for b in states]
    restored = [all(s < 0 or s == origin for origin, s in enumerate(b)) for b in states]
    all_actions = [[0, 1] for _ in states]
    cleanup = attractor(edges, restored, [[1] for _ in states])
    goals = [p and r for p, r in zip(pure, restored)]
    ranks = {
        'identify': attractor(edges, pure, all_actions),
        'restore': attractor(edges, goals, all_actions),
        'cleanup': cleanup,
        'abort': attractor(edges, goals, all_actions, [r is not None for r in cleanup]),
        'readonly': attractor(edges, pure, [[a for a in range(2) if stable[i][a]] for i in range(len(states))]),
    }
    root = index[tuple(range(n))]
    reset = len({tuple(code[2*s+a]%2 for a in range(2)) for s in range(n)}) == n
    pairwise = all(ranks['identify'][index[tuple(s if s in (i,j) else -1 for s in range(n))]] is not None
                   for i in range(n) for j in range(i+1,n))
    return states, edges, ranks, root, reset, pairwise
