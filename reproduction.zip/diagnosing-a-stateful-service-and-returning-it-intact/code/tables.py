"""Write the counts and LaTeX table rows of the paper from the result files."""
import json,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
s=json.load(open(R/'results'/'exhaustive_summary.json'))
v=json.load(open(R/'results'/'independent_verification.json'))
n=json.load(open(R/'results'/'native_summary.json'))
assert v['status']=='PASS' and n['status']=='PASS'
fmt=lambda x:f'{x:,}'
numbers={'Machines':s['rows'],'RankChecks':v['rank_entries_compared'],'PolicyReplays':v['winning_policy_replays'],
         'NativeTransitions':n['native_transition_probes'],'NativeEpisodes':n['persistent_policy_episodes'],'Interruptions':n['interrupted_prefix_episodes']}
for states in (2,3):
    for key,value in s['population'][str(states)]['counts'].items():numbers[f'N{states}{key.replace("_", "")}']=value
(R/'latex'/'numbers.tex').write_text(''.join('\\expandafter\\def\\csname Num'+k+'\\endcsname{'+fmt(x)+'}\n' for k,x in numbers.items()))
def table(filename,rows):
    (R/'latex'/filename).write_text(''.join(' & '.join(map(str,row))+r' \\'+'\n' for row in rows))
names=[('machines','Complete labelled population'),('reset','Resettable static-query baseline'),('pairwise','Every pair identifiable'),('identify','One continuous identification'),('restore','Identification and exact return'),('abort','Return with prefix cleanup'),('readonly','Identification by read-only actions')]
table('population_rows.tex',[(label,fmt(s['population']['2']['counts'][key]),fmt(s['population']['3']['counts'][key])) for key,label in names])
names=[('reset_false_admission','Static-query approval without return'),('identity_without_return','Identification without a return strategy'),('normal_without_abort','Normal return without prefix cleanup'),('pairwise_without_global','Pairwise separation without joint identification'),('restore_requires_mutation','Return requiring a mutating action')]
table('gap_rows.tex',[(label,fmt(s['population']['2']['counts'][key]),fmt(s['population']['3']['counts'][key])) for key,label in names])
labels={'peek':'Peek','consume':'Consume','write_restore':'Write restoration','blind_cleanup':'Restricted write cleanup','flip':'Flip','transaction':'Savepoint','external_audit':'Savepoint with external audit'}
table('native_rows.tex',[(labels[x['case']],x['states'],*[('$\\infty$' if x['root_ranks'][m] is None else x['root_ranks'][m]) for m in ('identify','restore','abort','readonly')]) for x in n['cases']])
print(json.dumps({'status':'PASS','macros':len(numbers),'generated_tables':3}))
