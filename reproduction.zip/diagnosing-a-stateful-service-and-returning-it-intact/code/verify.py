"""Independent bitset hypergraph oracle and serialized rank-certificate readback."""
import collections,gzip,heapq,itertools,json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
MODES=('identify','restore','cleanup','abort','readonly')

def oracle(n,table):
    beliefs=[]
    for choices in itertools.product(range(n+1),repeat=n):
        bits=sum(1<<(i*n+(s-1)) for i,s in enumerate(choices) if s)
        if bits:beliefs.append(bits)
    lookup={b:i for i,b in enumerate(beliefs)}
    origins=[[(k//n,k%n) for k in range(n*n) if b&(1<<k)] for b in beliefs]
    edges=[];readonly=[]
    for pairs in origins:
        row=[];ro=[]
        for a in (0,1):
            groups={}
            for origin,current in pairs:
                destination,observation=divmod(table[current*2+a],2)
                groups[observation]=groups.get(observation,0)|(1<<(origin*n+destination))
            row.append([lookup[v] for _,v in sorted(groups.items())])
            ro.append(all(table[s*2+a]//2==s for _,s in pairs))
        edges.append(row);readonly.append(ro)
    pure=[len(p)==1 for p in origins]
    returned=[all(i==s for i,s in p) for p in origins]
    both=[p and r for p,r in zip(pure,returned)]
    def heap_solve(goals,available,permitted):
        reverse=[[] for _ in beliefs];remaining={};largest={};ranks=[None]*len(beliefs);heap=[]
        for i in range(len(beliefs)):
            if not permitted[i]:continue
            if goals[i]:heapq.heappush(heap,(0,i))
            for a in available[i]:
                key=(i,a);remaining[key]=len(edges[i][a]);largest[key]=0
                for j in edges[i][a]:reverse[j].append(key)
        while heap:
            value,i=heapq.heappop(heap)
            if ranks[i] is not None:continue
            ranks[i]=value
            for key in reverse[i]:
                remaining[key]-=1;largest[key]=max(largest[key],value)
                if remaining[key]==0:heapq.heappush(heap,(largest[key]+1,key[0]))
        return ranks
    all_a=[[0,1] for _ in beliefs];all_p=[True]*len(beliefs)
    cleanup=heap_solve(returned,[[1] for _ in beliefs],all_p)
    ranks={'identify':heap_solve(pure,all_a,all_p),'restore':heap_solve(both,all_a,all_p),'cleanup':cleanup,
           'abort':heap_solve(both,all_a,[x is not None for x in cleanup]),
           'readonly':heap_solve(pure,[[a for a in (0,1) if readonly[i][a]] for i in range(len(beliefs))],all_p)}
    return beliefs,lookup,edges,origins,ranks

def main():
    started=time.monotonic();counts=collections.Counter();checks=0;replays=0
    expected_ids={2:0,3:0};hist={str(n):{m:collections.Counter() for m in MODES} for n in (2,3)}
    with gzip.open(ROOT/'data'/'exhaustive.jsonl.gz','rb') as inp:
        for line in inp:
            row=json.loads(line);n=row['n'];mid=row['id'];table=row['code']
            assert mid==expected_ids[n];expected_ids[n]+=1
            encoded=sum(x*(2*n)**(2*n-1-i) for i,x in enumerate(table));assert encoded==mid
            beliefs,index,edges,origins,computed=oracle(n,table)
            source_vectors=[b for b in itertools.product(range(-1,n),repeat=n) if any(s>=0 for s in b)]
            mapping=[index[sum(1<<(i*n+s) for i,s in enumerate(b) if s>=0)] for b in source_vectors]
            for mode in MODES:
                assert row['ranks'][mode]==[computed[mode][i] for i in mapping],(n,mid,mode)
                checks+=len(beliefs)
            root=index[sum(1<<(i*n+i) for i in range(n))];assert mapping[row['root']]==root
            reset=len(set(tuple(table[s*2+a]%2 for a in (0,1)) for s in range(n)))==n
            pairwise=all(computed['identify'][index[(1<<(i*n+i))|(1<<(j*n+j))]] is not None for i in range(n) for j in range(i+1,n))
            assert row['reset']==reset and row['pairwise']==pairwise
            win={m:computed[m][root] is not None for m in MODES}
            counts[(n,'machines')]+=1;counts[(n,'reset')]+=reset;counts[(n,'pairwise')]+=pairwise
            for m in MODES:
                counts[(n,m)]+=win[m]
                if win[m]:hist[str(n)][m][computed[m][root]]+=1
            tests={'reset_false_admission':reset and not win['restore'],'identity_without_return':win['identify'] and not win['restore'],
                   'normal_without_abort':win['restore'] and not win['abort'],'pairwise_without_global':pairwise and not win['identify'],
                   'restore_requires_mutation':win['restore'] and not win['readonly']}
            for k,v in tests.items():counts[(n,k)]+=v
            # Read every winning policy from the serialized ranks and execute it from every initial state.
            for mode in ('identify','restore','abort','readonly'):
                values=computed[mode]
                if values[root] is None:continue
                for true in range(n):
                    b=root;current=true;steps=0
                    while values[b]:
                        candidates=[]
                        for a in (0,1):
                            if mode=='readonly' and any(table[s*2+a]//2!=s for _,s in origins[b]):continue
                            if all(values[j] is not None for j in edges[b][a]):
                                candidates.append((1+max(values[j] for j in edges[b][a]),a))
                        cost,a=min(candidates);assert cost==values[b]
                        nxt,y=divmod(table[current*2+a],2)
                        b=next(j for j in edges[b][a] if any(i==true and s==nxt for i,s in origins[j]));current=nxt;steps+=1
                        assert steps<=values[root]
                        if mode=='abort':
                            cb=b;cs=current;remaining=computed['cleanup'][cb];assert remaining is not None
                            while remaining:
                                ns,cy=divmod(table[cs*2+1],2)
                                cb=next(j for j in edges[cb][1] if any(i==true and s==ns for i,s in origins[j]));cs=ns
                                assert computed['cleanup'][cb]<remaining;remaining=computed['cleanup'][cb]
                            assert cs==true
                    assert len(origins[b])==1 and origins[b][0][0]==true
                    if mode in ('restore','abort'):assert current==true
                    replays+=1
            if mid and mid%10000==0:print(json.dumps({'n':n,'checked':mid,'seconds':round(time.monotonic()-started,2)}),flush=True)
    assert expected_ids=={2:256,3:46656}
    summary=json.load(open(ROOT/'results'/'exhaustive_summary.json'))
    for n in (2,3):
        for k,v in summary['population'][str(n)]['counts'].items():assert v==counts[(n,k)],(n,k)
        for m in MODES:assert {str(k):v for k,v in hist[str(n)][m].items()}==summary['population'][str(n)]['depth'][m]
    result={'status':'PASS','machines':sum(expected_ids.values()),'rank_entries_compared':checks,'winning_policy_replays':replays,
            'discrepancies':0,'coverage':'all labelled machines, all nonempty origin/current configurations, all five contracts',
            'python':sys.version,'elapsed_seconds':time.monotonic()-started}
    (ROOT/'results'/'independent_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
