"""Run the four stages into runs/<timestamp>/ and check the results against expected.json."""
from pathlib import Path
import argparse, datetime, json, os, resource, shutil, subprocess, sys, time
p = argparse.ArgumentParser()
p.add_argument('--cpu-limit', type=int, default=18, help='CPU seconds per child process on POSIX systems')
a = p.parse_args()
if a.cpu_limit < 1:
    p.error('--cpu-limit must be positive')
root = Path(__file__).resolve().parent
run = root / 'runs' / datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
run.mkdir(parents=True)
folder = 'code'
shutil.copytree(root / folder, run / folder)
if (root / 'data').exists():
    shutil.copytree(root / 'data', run / 'data')
for d in ['results', 'latex']:
    (run / d).mkdir(exist_ok=True)
processes = []

def call(label, args):

    def light():
        os.nice(15)
        resource.setrlimit(resource.RLIMIT_CPU, (a.cpu_limit, a.cpu_limit))
    start = time.monotonic()
    r = subprocess.run(list(map(str, args)), cwd=run, capture_output=True, timeout=max(60, a.cpu_limit * 4), preexec_fn=light, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    (run / (label + '.stdout')).write_bytes(r.stdout)
    (run / (label + '.stderr')).write_bytes(r.stderr)
    processes.append({'label': label, 'exit': r.returncode, 'seconds': time.monotonic() - start})
    (run / 'processes.json').write_text(json.dumps(processes, indent=2) + '\n')
    if r.returncode:
        raise RuntimeError(label + ': ' + r.stderr.decode(errors='replace')[-3000:])
    print(label + ': PASS', flush=True)
py = [sys.executable, '-B']
for stage in ['compute', 'verify', 'native', 'tables']:
    call(stage, py + ['code/' + stage + '.py'])
META = {'python', 'elapsed_seconds', 'record_count', 'sqlite_version'}

def semantic(x):
    if isinstance(x, dict):
        return {k: semantic(v) for k, v in x.items() if k not in META}
    if isinstance(x, list):
        return [semantic(v) for v in x]
    return x
expected = json.loads((root / 'expected.json').read_text())
for name, want in expected.items():
    actual = semantic(json.loads((run / name).read_text()))
    assert actual == want, name
check = {'status': 'PASS', 'expected_result_files': len(expected), 'processes': processes, 'run': str(run)}
(run / 'CHECK.json').write_text(json.dumps(check, indent=2) + '\n')
print(json.dumps(check))
